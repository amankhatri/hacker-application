# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Hw9::Application.config.secret_token = 'd207c210d63f5d4f7d9fde469e8533ad78365801cd7811216714af0788c1eb05d5c866a3d22a60bf450674daee64e6f0429161aee4d5c610678a9f1b6525db55'
