<!DOCTYPE html PUBLIC
"-//W3C//DTD HTML 4.0 Transitional//EN"
"http://www.w3.org/TR/REC-html40/loose.dtd">
<html>
	<head><title>Homework 8</title></head>
	<body>
		<?php
		$sum=0;
		$country = $_POST["country"];
		
		$application_worked = FALSE;
		$conn = pg_connect("dbname=Something 
host=something port=something " .
                      " user=something  password=something");
$countries = array('Australia','Brazil','Canada','Denmark','Finland','France',
							     'Germany','Italy','Japan','Netherlands','Norway','Singapore',
							     'Sweden','UK','USA');

 if (in_array($country,$countries))
 {
 $token =array_search($country,$countries);
 $token++;
 if ($token == sizeof($countries)) {
$token = 0;
}
$nextCountry = $countries[$token];
}
			
		if ( $conn ) 
		{
	$result = pg_exec( $conn,
								"SELECT companyname, productname, unitprice, unitsinstock
		 " .
								"FROM products, 
		suppliers " .
								"WHERE 
		country=".'\''. $country .'\''. "AND products.supplierid=suppliers.supplierid");			
echo "<b>Supplying Country:</b> $country<br>";	
	
	if ( $result )
			{
				$rows = pg_numrows( $result );
				for ( $i=0; $i < $rows; $i++ )
				{
					$row = pg_fetch_row($result, $i);
					echo "<br>";
					echo "<b> Company:</b> $row[0] 
<b>Product:</b> $row[1]" .
					" <b>Unit Price:</b> $row[2] 
<b>Units in Stock:</b> $row[3] \n <br>";
$sum = $sum + $row[3];
					
				}
			}
			$application_worked = TRUE;
		}

		$status = pg_close( $conn );
		if ($application_worked == FALSE)
		{
			echo "<p class='error'>Database Error</p>\n";
		}


echo "<br>Total Number of Products from <b>$country</b> =<b> $sum </b><br>";

echo "<form action='kaman-8.php' method='post'>";

echo "<input type='hidden' name='country' value = $nextCountry>";
?>
<input type= "submit" value="Next">
</form>

<br>
<a href="kaman-8.txt">Scripting Code</a> 
<a href="kaman-8.jpg">Working of PHP!</a> 

	</body>
</html>
