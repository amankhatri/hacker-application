<!DOCTYPE html PUBLIC
"-//W3C//DTD HTML 4.0 Transitional//EN"
"http://www.w3.org/TR/REC-html40/loose.dtd">
<html>
	<head><title>Homework 7</title></head>
	<body>
		<?php
		$sum=0;
		$country = $_GET["country"];
		$application_worked = FALSE;
		$conn = pg_connect("dbname= 
host=something port=0000 " .
                      " user=user password=password");
		if ( $conn ) 
		{
	$result = pg_exec( $conn,
								"SELECT companyname, productname, unitprice, unitsinstock
		 " .
								"FROM products, 
		suppliers " .
								"WHERE 
		country=".'\''. $country .'\'');			
echo "<b>Supplying Country:</b> $country<br>";		
	if ( $result )
			{
				$rows = pg_numrows( $result );
				for ( $i=0; $i < $rows; $i++ )
				{
					$row = pg_fetch_row($result, $i);
					echo "<br>";
					echo "<b> Company:</b> $row[0] 
<b>Product:</b> $row[1]" .
					" <b>Unit Price:</b> $row[2] 
<b>Units in Stock:</b> $row[3] \n <br>";
$sum = $sum + $row[3];
					
				}
			}
			$application_worked = TRUE;
		}

		$status = pg_close( $conn );
		if ($application_worked == FALSE)
		{
			echo "<p class='error'>Database Error</p>\n";
		}
echo "<br>Total Number of Products from <b>$country</b> =<b> $sum </b><br>";
		?>
<br>
<a href="kamanPHP-7.txt">Scripting Code</a> 
	</body>
</html>
