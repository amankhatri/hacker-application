<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd"> 
<html>
<head>
<style type ="text/css">
table,td,th
{
border:1px solid green;

}
th
{
background-color:green;
color:white;
}
</style>

<title>HW5</title>
<link rel= "stylesheet" type = "text/css" href="stylesheet.css"/>

<?php

$firstName =  $_POST["fname"]; 
$setfname=1;
if ((!preg_match('/^[a-zA-Z-]+$/', $firstName))||((strlen($firstName)>=20)||(strlen($firstName)<=2))) {
   $firstName = '!!Enter Valid Data';
   $setfname=0;
}


$lastName =  $_POST["lname"]; 
$setlname=1;
if (!preg_match('/^[a-zA-Z-]+$/', $lastName)||((strlen($lastName)>=20)||(strlen($lastName)<=2))) {
     $lastName='!!Enter Valid Data ';
$setlname=0;
}

$setblazer=1;
$blazerId =   $_POST["bname"];
if (trim($blazerId)==""||!preg_match('/^[a-z0-9]+$/i',blazerId))
{
$blazerId= '!!Enter Valid Data ';
$setblazer=0;
}
if(($setblazer!=0)&&((strlen($blazerId)<=3)||(strlen($blazerId)>8)))
{
$blazerId='Enter Valid Data ';
$setblazer=0;
}


$telephoneNum =  $_POST["telNum"];
$setTel=1;
if(!is_numeric($telephoneNum))
{
$telephoneNum='!!Enter Valid Data';
$setTel=0;
}
if(($setTel!=0)&&(strlen($telephoneNum)!=10))
{
$setTel=0;
$telephoneNum='!!Enter Valid Data';
}


$teamNum =   $_POST["teamNum"]; 
$setTeam=1;
if (!preg_match("/^[1-6]$/", $teamNum)&&(($teamNum>6)||($teamNum<1))) {
    $setTeam=0;
   $teamNum = '!!Enter Valid Data ';
}

$totalTime = $_POST["totalTime"];
$setTime=1;
if (!is_numeric($totalTime)&&($totalTime<=168||$totalTime<=0))
{
echo "Enter Valid Time";
$totalTime = '';
$setTime=0;
}
$result=0;
$analysis = $_POST["analysis"];
$setAnalysis=1;
if ((!is_numeric($analysis))||(($analysis>=100)||($analysis<=1)))
{
$setAnalysis=0;
$aTime ='!!Enter Valid Date';
$Date ='!!Could Not be Produced Due to Invalid Data';
}


$design = $_POST["design"];
$setDesign=1;
if((!is_numeric($design))||(($design>=(100-$analysis)||$design<=1)))
{
$setDesign =0;
$dTime ='!!Enter Valid Data ';
$Date='!!Could Not be Produced Due to Invalid Data';
}


$coding =$_POST["coding"];
$setCoding=1;
if(!is_numeric($coding)||$coding>=(100-$design-$analysis)||$coding<=1)
{
$setCoding=0;
$cTime = '!!Enter Valid Data ';
$Date = '!!Could Not be Produced Due to Invalid Data';
}

$testing = $_POST["testing"];
$setTesting=1;
$result =$design+$coding+$analysis;
if(!is_numeric($testing)||$testing>=(100-$result)||$testing<=1)
{
$setTesting = 0;
$tTime='!!Enter Valid Data ';
$Date ='!!Could Not be Produced Due to Invalid Data';
}
$result=$result+$testing;

$other =$_POST["other"];
$setOther = 1;
if(!is_numeric($other)||$other>=(100-$result)||$other<=1)
{
$setOther =0;
$oTime = '!!Enter Valid Data';
$Date ='!!Could Not be Produced Due to Invalid Data';
}

$proceed=0;
if($setfname!=0&&$setlname!=0&&$setblazer!=0&&$setTel!=0&&$setTeam!=0&&$setTime!=0&&$setAnalysis!=0&&$setDesign!=0&&$setCoding!=0&&$setTesting!=0&&$setOther!=0)
{
$proceed=1;
date_default_timezone_set('America/chicago');
$Date = date('m/d/y h:i:s a',time());
$aTime='!!Enter Valid Data';
$aTime=$totalTime*$analysis*0.01;
$dTime=$totalTime*$design*0.01;
$cTime=$totalTime*$coding*0.01;
$tTime=$totalTime*$testing*0.01;
$oTime=$totalTime*$other*0.01;
}
?>

</head>
<body>
<table>
<tr>
<td><?php echo "First Name"; ?></td>
<td><?php print "$firstName"; ?> </td>
</tr>

<tr>
<td><?php echo "Last Name";?></td>
<td><?php print "$lastName";?></td>
</tr>

<tr>
<td><?php echo "Blazer Id";?></td>
<td><?php print "$blazerId";?></td>
</tr>

<tr>
<td><?php echo "Telephone";?></td>
<td><?php print "$telephoneNum";?></td>
</tr>

<tr>
<td><?php echo "Team Number";?></td>
<td><?php print "$teamNum";?></td>
</tr>


<tr>
<td><?php echo "Analysis Time";?></td>
<td><?php print "$aTime ";?></td>
</tr>

<tr>
<td><?php echo "Design Time";?></td>
<td><?php print "$dTime ";?></td>
</tr>


<tr>
<td><?php echo "Coding Time";?></td>
<td><?php print "$cTime ";?></td>
</tr>

<tr>
<td><?php echo "Testing Time";?></td>
<td><?php print "$tTime ";?></td>
</tr>

<tr>
<td><?php echo "Other Time";?></td>
<td><?php print "$oTime ";?></td>
</tr>

<tr>
<td><?php echo "Time Stamp"; ?> </td>
<td><?php print "$Date"; ?> </td>
</tr>
</table>
<br>
<br>

<p><?php if($setfname!=1){ echo "<br>*Enter Valid First Name: Name should contain characters 
[A-Z/a-z/A-z]<br> 
<br> and must have less then 20 characters<br>";}?></p>
<p><?php if($setlname!=1){ echo "<br>*Enter Valid  Last Name: Name should contain characters 
[A-Z/a-z/A-z]<br>
<br> and must have less then 20 characters.<br>";}?></p>
<p><?php if($setblazer!=1){echo "<br>*Enter Valid Blazer ID: It can contain [A-z/a-z/A-z/0-9]<br>
<br> and must have more then 3 but less then 9 characters.<br>";}?></p>
<p><?php if($setTel!=1){echo "<br>*Enter Valid Phone Number: It must contain digits [0-9]<br>
<br> and must have 10 digits.<br>";}?></p>
<p><?php if($setTeam!=1){echo "<br>*Enter Valid Team Number: It must contain a single digit 
[1-6].<br>";}?></p>
<p><?php if($setTime!=1){echo "<br>*Enter Valid Time: it must contain numbers only [0-9]<br>
<br> and must be less 168.<br>";}?></p> 
<p><?php if($setAnalysis!=1){echo "<br>*Enter Valid Time in percent for Analysis: It must contain numbers 
only [1-9] 
<br>
<br> and must be less then total time.<br>";}?></p>
<p><?php if($setDesign!=1){echo "<br>*Enter Valid Time in percent  for Design: It must contain numbers only 
[1-9]<br>
<br> and must be less then total time.<br>";}?></p>
<p><?php if($setCoding!=1){echo "<br>*Enter Valid Time in percent  for Coding: It must contain numbers only 
[1-9]<br>
<br> and must be less then total time.<br>";}?></p>
<p><?php if($setTesting!=1){echo "<br>*Enter Valid Time in percent for Testing: It must contain numbers 
only [1-9] <br>
<br> and must be less then total time.<br>";}?></p>
<p><?php if($setOther!=1){echo "<br>*Enter Valid Time in percent for Other Work: It must contain numbers
only [1-9] <br>
<br>and must be less then total time.<br>";}?></p>

<p><?php if($proceed!=0)
{
$filename="Homework5.txt";
$pointer=fopen($filename,'a+');
fwrite($pointer,"-------------------------------------------------------------------");
fwrite($pointer,$Date);
fwrite($pointer,"-------------------------------------------------------------------");
fwrite($pointer,"\n");
fwrite($pointer,"First Name:	");
fwrite($pointer,$firstName);
fwrite($pointer,"\n");
fwrite($pointer,"Last Name:	");
fwrite($pointer,$lastName);
fwrite($pointer,"\n");
fwrite($pointer,"Blazer ID:	");
fwrite($pointer,$blazerId);
fwrite($pointer,"\n");
fwrite($pointer,"Telephone:	");
fwrite($pointer,$telephoneNum);
fwrite($pointer,"\n");
fwrite($pointer,"Team Number:	");
fwrite($pointer,$teamNum);
fwrite($pointer,"\n");
fwrite($pointer,"Analysis Time:	");
fwrite($pointer,$aTime);
fwrite($pointer,"\n");
fwrite($pointer,"Design Time:	");
fwrite($pointer,$dTime);
fwrite($pointer,"\n");
fwrite($pointer,"Coding Time:	");
fwrite($pointer,$cTime);
fwrite($pointer,"\n");
fwrite($pointer,"Testing Time:	");
fwrite($pointer,$tTime);
fwrite($pointer,"\n");
fwrite($pointer,"Other Time:	");
fwrite($pointer,$oTime);
fwrite($pointer,"\n");
fwrite($pointer,"Time Stamp:	");
fwrite($pointer,$Date);
fwrite($pointer,"\n");
fwrite($pointer,"\n");
fwrite($pointer,"------------------------------------------------------------------------------");
fwrite($pointer,"------------------------------------------------------------------------------\n");
fwrite($pointer,"\n");
fwrite($pointer,"\n");
fwrite($pointer,"\n");
fwrite($pointer,"\n");
fwrite($pointer,"\n");

chmod("Homework5",0755);
fclose($pointer);

}
?></p>
<a href ="Homework5.txt"><b><u>LOG FILE</u></b></a>
</body>
</html>
