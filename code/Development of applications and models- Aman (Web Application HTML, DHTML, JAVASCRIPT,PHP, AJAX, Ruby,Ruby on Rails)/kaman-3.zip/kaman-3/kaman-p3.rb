#!/usr/bin/env ruby

require 'cgi'

# get instance of CGI class
cgi = CGI.new

# read each of the single value parameters, convert from 
# strings to numbers

# note: cgi.params['ans'] returns array which can have 0 or more elements

a = cgi['frstNum'].to_i
b = cgi['secNum'].to_i
operation = cgi['Operation']
if operation == "Add"
values = a+b
elsif operation == "Substract"
values = a-b
elsif operation == "Multiply"
values  = a*b
elsif operation == "Modulus"
values = a%b
end
print <<ENDPAGE
Content-type: text/html

ENDPAGE

# read the original file, insert answer into form, and display
infile = File.new("../p3.html", "r")

infile.each do | line | 

 
  line.gsub!(/^(.*value=")(" id="secNum".*)$/,"\\1#{values}\\2")
  puts line
end
