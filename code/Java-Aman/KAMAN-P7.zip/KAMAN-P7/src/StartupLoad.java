/** File: StartupLoad.java
 * Author: Aman Khatri <kaman@uab.edu>
 * Assignment:  P7 - EE333 Fall 2009
 * Vers: 1.0.0 10/25/2011 kaman - initial coding
 * */

import org.apache.log4j.Logger;
import java.lang.String;

/**
 *
 * @author kaman
 */
public class StartupLoad extends Load {

    private static Logger logger = Logger.getLogger(StartupLoad.class);
    double startCurrent;
    double finalCurrent;
    double rampTime;
    Clock clk = Clock.getInstance();
    /*
     * Constutor Startup load requires the name of the load , start current, the 
     * ramptime and the final current
     */

    public StartupLoad(String nameLoad, double startcurrent, double rampTime, double finalCurrent) {
        super(nameLoad);
        this.startCurrent = startcurrent;
        this.rampTime = rampTime;
        this.finalCurrent = finalCurrent;
    }
    /*
     * returns the value of start current for the startup load
     */

    public double getInitialCurrent() {
        return startCurrent;
    }
    /*
     * returns final current of start up load
     */

    public double getFinalCurrent() {
        return finalCurrent;
    }
    /*
     * this method returns the time which current takes to reach a constant value
     */

    public double getRampTime() {
        return rampTime;
    }
    /*
     * method returns the rate of change of the current
     */

    public double currentRate() {
        return ((startCurrent - finalCurrent) / rampTime);
    }
    /*
     * method returns the value of current at each instant of time
     */

    public double gettotalCurrent() {
        while ((startCurrent + currentRate() * clk.getTime()) < finalCurrent) {
            logger.info("Present Gscfss Current: " + startCurrent + currentRate() * clk.getTime());
            return (startCurrent + currentRate() * clk.getTime());
        }
        if (startCurrent == finalCurrent) {
            return finalCurrent;
        } else {
            return finalCurrent;
        }


    }
    /*
     * this method gets current from the load
     */

    @Override
    public double getCurrent() {
        return finalCurrent;
    }

    public String getLoadType() {
        return "STARTUP_LOAD";
    }
   
}
