
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;

/** File: Generator.java
 * Author: Aman Khatri <kaman@uab.edu>
 * Assignment:  P7 - EE333 Fall 2009
 * Vers: 1.0.0 10/25/2011 kaman - initial coding
 * /

/**
 *
 * @author kaman
 */
public class Generator {

    private boolean on = false;
    Clock clk = Clock.getInstance();
    private double maximumCurrent;
    private double remainingCurrent;
    private double maxRunTime;
    private double CurrentRunTime;
    public double remainingTime;
    /*
     * Constructor "Generator" is takes the maximum current capcity for creating 
     * a generator. Also it takes the value of run time of the generator
     */
    private static Logger logger = Logger.getLogger(Generator.class);

    public Generator(double maxCurrent, double runTime) {
        this.maximumCurrent = maxCurrent;
        this.maxRunTime = runTime;
        this.remainingCurrent = this.maximumCurrent;
    }
    /*
     * Returns the maximum current capcity of the generator
     */

    public double getMaxCurrent() {
        System.out.println("maximumCurrent");
        return maximumCurrent;

    }
    /*
     * Method is used for calculating Remaining current
     */

    public double calculateRemainingCurrent(List<PowerSocket> pSocketList) {
        double totalUsedCurrent = 0;
        double remainingCurrent = maximumCurrent;
        for (int i = 0; i < pSocketList.size(); i++) {
            PowerSocket p = pSocketList.get(i);
            if (p.checkPluggedIn()) {
                totalUsedCurrent += p.getLoad().getCurrent();
                remainingCurrent = getRemainingCurrent() - totalUsedCurrent;

            }
        }
        remainingCurrent = remainingCurrent - totalUsedCurrent;
        //setRemainingCurrent(remainingCurrent);
        return remainingCurrent;
    }
    /*
     * returns the remaining current
     */

    public double getRemainingCurrent() {
        return remainingCurrent;
    }
    /*
     * this method calculates reamining time
     */

    public double remainingTime() {
        if (isOn()) {
            if (maxRunTime > 0) {
                remainingTime = maxRunTime - clk.getTime();
            }
            logger.info("Remaining Time: " + remainingTime);
            return remainingTime;
        } else {
            return remainingTime = 0;
        }

    }

    /*
     * this method refuel
     */
    public double refuel() {
        remainingTime = maxRunTime;
        return remainingTime;
    }
    /*
     * this methods turns on the generator
     */

    public void turnOn(ArrayList<PowerSocket> pSocketList) {
        ElectricalDevice eDevice;
        on = true;

        for (int i = 0; i < pSocketList.size(); i++) {
            eDevice = pSocketList.get(i).getLoad();

            if (eDevice.getLoadType() == "CONSTANT_LOAD") {
                if (this.getRemainingCurrent() > eDevice.getCurrent()) {
                    clk.step();
                    eDevice.turnOn();
                }
            } else if (eDevice.getLoadType() == "STARTUP_LOAD") {
                int iterations = (int) (((StartupLoad) eDevice).getRampTime() / 0.5);
                for (i = 1; i <= iterations; i++) {
                    clk.step();

                    double remCurrent = this.getRemainingCurrent() - (((StartupLoad) eDevice).currentRate());
                    this.setRemainingCurrent(remCurrent);
                    //logger.info("the total current consumed by load : "+((StartupLoad)eDevice).gettotalCurrent());
                    //  logger.info("Present Generator Current: " + this.getRemainingCurrent());

                }
                if (this.getRemainingCurrent() > eDevice.getCurrent()) {
                }
            }
        }
    }
    /*
     * this method turns off the generator
     */

    public void turnOff(ArrayList<PowerSocket> pSocketList) {
        ElectricalDevice eDevice;
        for (int i = pSocketList.size(); i >= 0; i--) {
            eDevice = pSocketList.get(i).getLoad();
            if (eDevice.getLoadType() == "CONSTANT_LOAD") // ||maximumCurrent<eDevice.getCurrent())
            {
                if (this.remainingCurrent < eDevice.getCurrent()) {
                    on = false;
                    pSocketList.remove(i);
                } else {
                    on = false;
                    pSocketList.remove(i);
                }
            } else if (eDevice.getLoadType() == "STARTUP_LOAD") {
                StartupLoad sL = (StartupLoad) eDevice;
                if (this.remainingCurrent < sL.getCurrent()) {
                    clk.setTime(clk.getTime() + sL.getRampTime());
                    on = false;

                } else {
                    clk.setTime(clk.getTime() + sL.getRampTime());
                    on = false;
                }
            } else {
                System.out.println("Error no Load Plugged In");
            }
        }
    }
    /*
     * checks if the generator is switched on
     */

    public boolean isOn() {
        if (remainingTime != 0 && on == true) {
            return true;
        } else {
            return false;
        }
    }

    /*
     *assigingn a value of remaining time to a variable 
     */
    public void setRemainingCurrent(double remainder) {
        // logger.info("faCurrent: " + remainder);
        this.remainingCurrent = remainder;
    }
}
