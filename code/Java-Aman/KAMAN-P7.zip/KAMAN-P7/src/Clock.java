
import org.apache.log4j.Logger;

/** File: Clock.java
 * Author: Aman Khatri <kaman@uab.edu>
 * Assignment:  P7 - EE333 Fall 2009
 * Vers: 1.0.0 10/25/2011 kaman - initial coding
 * */
/**
 *
 * @author kaman
 */
public class Clock {

    private double startTime;
    private double time;
    private double step = 0.5;
    private static Clock clkobj;
    private static Logger logger = Logger.getLogger(Clock.class);

    /*
     * 
     */
    private Clock() {
    }

    public static synchronized Clock getInstance() {
        if (null == clkobj) {
            clkobj = new Clock();
        }
        return clkobj;

    }
    /*
     * 
     */

    public double startTime() {
        return startTime();
    }

    /*
     * this method displays the time in periods of 0.5 seconds
     */
    public void step() {
        time = time + step;
        logger.info("Present Clock time: " + time);
    }
    /*
     * This method is used to display the time
     */

    public double getTime() {
        logger.info("Time" + time);
        return time;
    }
    /*
     * This method is used to set the time
     */

    public void setTime(double t) {
        time = t;
    }
}
