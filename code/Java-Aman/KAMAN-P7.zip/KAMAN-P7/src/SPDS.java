
import java.util.ArrayList;
import org.apache.log4j.Logger;


/** File: SPDS.java
 * Author: Aman Khatri <kaman@uab.edu>
 * Assignment:  P7 - EE333 Fall 2009
 * Vers: 1.0.0 10/25/2011 kaman - initial coding
 * /
/**
 *
 * @author Rekha
 */
public class SPDS {

    private Generator gen;
    private int numberPowerSockets;
    private ArrayList<PowerSocket> pSocketList = new ArrayList<PowerSocket>();// Array of type Power Sockets
    Clock clk = Clock.getInstance();
    private static Logger logger = Logger.getLogger(SPDS.class);
    /*
     * construtctor requires the number of power sockets
     */

    public SPDS(int numberPowerSockets) {
        this.numberPowerSockets = numberPowerSockets;      //Prompting for Number of Sockets
    }
    /*
     * this methods is used to set the source to generator
     */

   public void setSource(Generator gen) // setting the source to generator
    {
        this.gen = gen;
    }
   /*
     *  this method returns the source
     */

   public Generator getSource() {
        return gen;
    }
    /*
     * this turns on the generator
     */

    public void switchGen() // switching on the generator
    {
        this.gen.turnOn(this.pSocketList);
    }
    /*
     * This method is used to initialize the sockets
     */

    public void initializeSockets() {
        for (int i = 0; i < numberPowerSockets; i++) {
            PowerSocket socket = new PowerSocket();
            pSocketList.add(socket);
        }
    }
    /*
     * 
     */

    public ArrayList<PowerSocket> getPSocketList() {
        return pSocketList;
    }
    /*
     * THis method is used to plug in the electrical device.
     */

    public void plugIn(int i, ElectricalDevice ed) {
        if (i < numberPowerSockets) // if there is socket available then
        {
            PowerSocket pwr = pSocketList.get(i);            // add it to power socket list
            if (!pwr.checkPluggedIn()) // checking to see if anything is plugged in the socket
            {
                pwr.plug(ed);                              // plug in the electrical device
                if (this.gen.isOn() == false) {
                    ed = pSocketList.get(i).getLoad();
                    if (ed.getLoadType() == "CONSTANT_LOAD") {
                        if (this.gen.getRemainingCurrent() > ed.getCurrent()) {
                            // clk.step();
                            ed.turnOn();
                        }
                    } else if (this.gen.isOn() == false && ed.getLoadType() == "STARTUP_LOAD") {
                        int iterations = (int) (((StartupLoad) ed).getRampTime() * 2);
                        for (i = 1; i <= iterations; i++) {
                            clk.step();
                            gen.calculateRemainingCurrent(pSocketList);
                            //double remCurrent = gen.getRemainingCurrent()-(((StartupLoad)ed).currentRate());
                            //this.gen.setRemainingCurrent(remCurrent);
                            //logger.info("Present Remaining Generator Current: " + gen.getRemainingCurrent());
                        }
                        if (this.gen.getRemainingCurrent() > ed.getCurrent()) {
                            //gen.setRemainingCurrent(gen.getRemainingCurrent()-ed.getCurrent());
                        }
                    }

                }
            }
            logger.info("Present Remaining Generator Current: " + (gen.getRemainingCurrent() - ed.getCurrent()));
        } else {
            // logger.info(" there is no socket available");
        }
    }
    /*
     * this plug is used to unplug a specific electrical deivece
     */

    public void unplug(int i) {
        pSocketList.remove(i);
    }
    /*
     * this method is used to increase the time 
     */

    public void step() {
        clk.step();
    }
}