/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kaman
 */
public class PowerSocket {
    private ElectricalDevice eDevice;
    private boolean isPluggedIn = false; // Variable to check if the device is already plugged in
    
public PowerSocket(){
        
    }
    
    public ElectricalDevice getLoad(){
        return eDevice;
    }
    
    public void plug(ElectricalDevice eDevice){
        this.eDevice = eDevice;
        ((Load)eDevice).setIsPluggedIn(true);
        isPluggedIn = true;
    }
    
    public void unplug(){
        this.eDevice=null;
        isPluggedIn = false;
    }
    
    public double getCurrent(){
       return(this.eDevice.getCurrent()) ;
    }
    
    public  double getInitialCurrent(){
        
      return(eDevice.getCurrent());
    }
    //public double getFinalCurrent()
   // {
     //   return(Device.getFinalCurrent());
    //}
    
    public void turnOn(){
        this.eDevice.turnOn();
    }
    
    public void turnOff(){
        this.eDevice.turnOff();
    }
    
    public String getName(){
        return(this.eDevice.getName());
    }
    
    public boolean checkPluggedIn(){
        return isPluggedIn;
    }

}
