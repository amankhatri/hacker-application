/** File: ElectricalDevice.java
 * Author: Aman Khatri <kaman@uab.edu>
 * Assignment:  P7 - EE333 Fall 2009
 * Vers: 1.0.0 10/25/2011 kaman - initial coding
 * */

/**
 *
 * @author kaman
 */
public interface ElectricalDevice {

    void turnOn();

    void turnOff();

    String getName();

    double getCurrent();

    String getLoadType();
}
