/** File: ConstantLoad.java
 * Author: Aman Khatri <kaman@uab.edu>
 * Assignment:  P7 - EE333 Fall 2009
 * Vers: 1.0.0 10/25/2011 kaman - initial coding
 * */

/**
 *
 * @author kaman
 */
public class ConstantLoad extends Load {

    private double current;
    private boolean on = false;
    /*
     * 
     */

    public ConstantLoad(String NameLoad, double CurrentRequired) {
        super(NameLoad);
        this.current = CurrentRequired;
        this.on = false;
    }
    /*
     * this method returns the current required by the constant load
     */

    @Override
    public double getCurrent() {
        return current;
    }
    /*
     * This method returns the type of load to the Electrical to LOAD
     */
   
    public String getLoadType() {
        return "CONSTANT_LOAD";
    }
}
