/** File: Demo.java
 * Author: Aman Khatri <kaman@uab.edu>
 * Assignment:  P7 - EE333 Fall 2009
 * Vers: 1.0.0 10/25/2011 kaman - initial coding
 * */
import java.io.IOException;
import org.apache.log4j.Logger;
import org.apache.log4j.Appender;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.FileAppender;
import org.apache.log4j.SimpleLayout;

/**
 * This Program Uses 'Apache Log4j-1.2.16.jar' to create logs of the file
 * please make sure that its in your library Also, I have included it in my Project Folder
 * All the Data Logged will be saved in the folder named 'Log' inside the main project folder
 * @author kaman
 */
public class Demo {

    public static void main(String[] args) {
        System.out.println("This Program Uses 'Apache Log4j-1.2.16.jar' to create logs of the file"
                + "please make sure that its in your library Also, I have included it in my Project Folder ");
        System.out.println("All the Data Logged will be saved in the folder named 'Log' inside the main project folder");

        Logger logger = Logger.getLogger(SPDS.class);
        BasicConfigurator.configure();
        Appender appender = null;

        try {
            appender = new FileAppender(new SimpleLayout(), "log/logs.txt");
            logger.addAppender(appender);

        } catch (IOException e) {
        }

        logger.info("Starting Application");

        Generator gen = new Generator(100, 1000);
        SPDS spds = new SPDS(5);
        Clock clk = Clock.getInstance();
        spds.initializeSockets();
        spds.setSource(gen);

        // gen.turnOn(PowerSocket pSocketlist);
        spds.plugIn(0, new ConstantLoad("CL1", 1.12));
        spds.plugIn(1, new StartupLoad("SL1", 0, 2, 2));
        spds.plugIn(2, new StartupLoad("SL2", 1, 2, 2));
        spds.plugIn(3, new ConstantLoad("CL2", 10));
        spds.plugIn(4, new StartupLoad("SL3", 5, 5, 10));
       
        System.out.println( "Refuel " + gen.refuel());
         System.out.println("Maximum  current "+gen.getMaxCurrent());




    }
}
