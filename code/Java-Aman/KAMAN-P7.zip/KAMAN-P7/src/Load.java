/** File: Load.java
 * Author: Aman Khatri <kaman@uab.edu>
 * Assignment:  P7 - EE333 Fall 2009
 * Vers: 1.0.0 10/25/2011 kaman - initial coding
 * */

import org.apache.log4j.Logger;

/**
 *
 * @author kaman
 */
/*
 * This class Implements Electrical Device All loads are oprated using this class 
 * Functions of Class are to Turn On/Turn Off load and to get Information about 
 * There type (constant and transients)
 */
public abstract class Load implements ElectricalDevice {

    private static Logger logger = Logger.getLogger(Load.class);
    private String name;
    private boolean isPluggedIn;
    private boolean on;
    /*
     * 
     */

    public Load(String name) {
        this.name = name;
        logger.info("Name of Load: " + this.name);
    }
    /*
     * This Method Turns On the load
     */

    @Override
    public void turnOn() {
        on = true;
    }
    /*
     * This method Turns off the load
     */

    @Override
    public void turnOff() {
        on = false;
    }
    /*
     * This Method returns the name of the Load
     */

    @Override
    public String getName() {
        return name;
    }
  
    /*
     * This method gets the current form the two load classes
     */

    @Override
    public abstract double getCurrent();

    @Override
    public abstract String getLoadType();

    public boolean isIsPluggedIn() {
        return isPluggedIn;
    }

    public void setIsPluggedIn(boolean isPluggedIn) {
        this.isPluggedIn = isPluggedIn;
    }
}
