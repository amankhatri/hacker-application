/**
 * File: PositionMonitor.java
 * Author: Aman Khatri, (kaman@uab.edu)
 * Assignment: Project 5 EE333 Fall 2010
 * Ver:  1.0.2 09/15/2011 furnishing the program 
 * Vers: 1.0.1 09/14/2011 fix order of items 
 * Vers: 1.0.0 09/12/2011 initial coding 
 * Credits:  NA
 */



public interface PositionMonitor {
    /**
     * Method called to update position and error state
     * @param tag - array of labels (parallel to value)
     * @param value - array of values (parallel to tag)
     * @param error - true if in error state
     */
    void positionChanged( String[] tag, int[] value, boolean error );
}
