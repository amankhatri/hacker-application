/**
 * File: IndexTable.java
 * Author: Aman Khatri, (kaman@uab.edu)
 * Assignment: Project 3 EE333 Fall 2010
 * Ver:  1.0.2 09/15/2011 furnishing the program
 * Vers: 1.0.1 09/14/2011 fix order of items
 * Vers: 1.0.0 09/12/2011 initial coding
 * Credits:  NA
 */
public class PositionMonitorDemo {
    
    /**
     * Demo program moving table 1 (print) without error
     *              moving table 1 (print) with error
     *              moving table 2 (alarm) without error
     *              moving table3 2 (alarm) with error
     * @param args
     */
    public static void main(String[] args) {
    
        PositionMonitor pmPrint = new PrintingPositionMonitor();
        PositionMonitor pmAlarm = new AlarmingPositionMonitor();
        PositionMonitor pmPrint2 = new PrintingPositionMonitor();
        PositionMonitor pmAlarm2 = new AlarmingPositionMonitor();
        
        IndexTable instance = new IndexTable(1000, 1000, pmPrint, pmAlarm);
        IndexTable object = new IndexTable(2000, 2000, pmPrint2, pmAlarm2);
        
        

        
        instance.move(100, 100);
        instance.isComplete();
        
        instance.move(2000, 2000);
        instance.isComplete();
        
        object.move(1000, 1000);
        object.isComplete();
        
        object.move(4000, 4000);
        object.isComplete();
    }
}
