/**
 * File: PrintingPositionMonitor.java
 * Author: Aman Khatri, (kaman@uab.edu)
 * Assignment: Project 3 EE333 Fall 2010
 * Ver:  1.0.2 09/15/2011 furnishing the program
 * Vers: 1.0.1 09/14/2011 fix order of items 
 * Vers: 1.0.0 09/12/2011 initial coding By David Green
 * Credits:  NA
 */
public class PrintingPositionMonitor implements PositionMonitor {

    /**
     * Method called to update position and error state
     * @param tag - array of labels (parallel to value)
     * @param value - array of values (parallel to tag)
     * @param error - true if in error state
     */
    @Override
    public void positionChanged(String[] tag, int[] value, boolean error) {
        
        int numberItems = Math.min( tag.length, value.length );
        
        String message = "Device is ";
        message += error ? "in error state" : "operating normally";
        message += ".  It reports its position";
        for (int i = 0; i < numberItems; i++) {
            message += " " + tag[i] + "=" + value[i];
        }
        System.out.println(message);
    }
    
}
