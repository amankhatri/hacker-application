/**
 * File: IndexTable.java
 * Author: Aman Khatri, (kaman@uab.edu)
 * Assignment: Project 3 EE333 Fall 2010
 * Ver:  1.0.2 09/15/2011 furnishing the program
 * Vers: 1.0.1 09/14/2011 fix order of items
 * Vers: 1.0.0 09/12/2011 initial coding
 * Credits:  David Green <dgreen@uab.edu>
 */
import java.util.*;

public class IndexTable {

    private static int tableCount = 0;
    private int serialNumber;
    
    private int bookedDX;   // delta X, Y to be accomplished at is_complete time
    private int bookedDY;
    private int x;
    private int y;
    private int maxX;
    private int maxY;
    
    private double timeElapsed;
    
    private boolean errorOccurred;
    private ArrayList<PositionMonitor> positionMonitor = new ArrayList<PositionMonitor>();
    
    /*
     * Remove access to default constructor
     */
    private IndexTable() {
    }
    
    /**
     * Construct an IndexTable with table size and a possible PositionMonitor
     * @param maxX - maximum x limit for table
     * @param maxY - maximum y limit for table
     * @param positionMonitor - object implementing PostionMonitor interface
     *        to be called when table changes state
     */
    public IndexTable( int maxX, int maxY, PositionMonitor ... positionMonitor ) {
        this.maxX = maxX;
        this.maxY = maxY;
        this.serialNumber = ++(IndexTable.tableCount);
        privateReset();             // avoid this being overriden in constructor
        for(PositionMonitor var: positionMonitor)
        {
          //this.positionMonitor[i++] = var;
            this.positionMonitor.add(var);
          
        }

    }
    
    // Queries
    
    /**
     * 
     * @return true if not in error state, false otherwise
     */
    public boolean isOK() {
        return !isError();
    }
    
    /**
     * 
     * @return true if in error state, false otherwise
     */
    public boolean isError() {
        return errorOccurred;
    }

    /**
     * 
     * @return true if table is known to be at 0,0 else returns false
     */
    public boolean isHome() {
        return ( x == 0 && y == 0 );
    }
    
    /**
     * 
     * @return present x coordinate of table
     */
    public int getX() {
        return bookedDX;
    }
    
    /**
     * 
     * @return present y coordinate of table
     */
    public int getY() {
        return bookedDY;
    }
    
    /**
     * 
     * @return <serialNumber>, <status>, <xPosition> <yPosition>
     */
    @Override
    public String toString() {
        String status = isOK() ? "OK" : "Error";
        return "" + serialNumber + ", " + status + ", " + getX() + " " + getY();
    }

    // the following appear to be queries but might change internal state
    
    /**
     * Books actual move of table and the time it took
     * @return true always
     */
    public boolean isComplete() {
        x += bookedDX;
        y += bookedDY;
                
        timeElapsed += timeCalc(bookedDX, bookedDY);        

        bookedDX = 0;                   // clear booked movement
        bookedDY = 0;
        
        tableStateChanged();
        
        return true;
    }
    
    /**
     * 
     * @return time elapsed since last call of this method
     */
    public double time_elapsed() {
        return timeCalc(getX(),getY());
        
    }
    
    // Commands
    
    /**
     * reset any error condition in table (just the flag)
     */
    public void resetError() {
        this.errorOccurred = false;

        tableStateChanged();
    }
    
    /**
     * reset the table to original state (0, 0, no error, 
     * no pending elapsed time)
     */
    public void reset() {
        privateReset();

        tableStateChanged();
    }
    
    /**
     * Book the movement to a new x, y location
     * Error out if that would be out of bounds without moving table
     * @param x
     * @param y
     */
    public void move(int x, int y) {
        if ( errorOccurred )
            return;                      // don't do anything if in error state
        if ( x <= maxX && y <= maxY ) {
            bookedDX = x - this.x;       // book move if legal
            bookedDY = y - this.y;
        } else {
            errorOccurred = true;        // if not legal, set error
        }
            
        tableStateChanged();
    }
    
    /**
     * Move relative amount (same behavior as move)
     * @param dx
     * @param dy
     */
    public void moveRelative(int dx, int dy) {
        move( this.getX() + dx, this.getY() + dy );
        
        tableStateChanged();
    }
    
    /**
     * Move vector amount relative to present position (same behavior as move)
     * @param r
     * @param theta
     */
    public void moveVector(int r, int theta) {
        // convert vector to rectangular with rounding
        int dx = (int) ( r * Math.cos( Math.PI * theta / 180.) + .5 );
        int dy = (int) ( r * Math.sin( Math.PI * theta / 180.) + .5 );
        
        moveRelative(dx, dy);
        
        tableStateChanged();
    }
    
    /*
     * Compute the time based on dx, dy and supplied algorithm
     */
    private double timeCalc(int dx, int dy) {
        double distance = Math.sqrt( (getX()*getX() + getY()*getY()));
        if(distance>100){
            double t= 4 + (distance-100)/50;
            return t;
        }
        else{
            double t = Math.sqrt(distance/25);
        return (2*t);
        }
    }

    /*
     * Do reset here in method that can not be overridden so contructor not at
     * risk.
     */
    private void privateReset() {
        this.x = 0;
        this.y = 0;
        bookedDX=0;
        bookedDY=0;
        this.errorOccurred = false;
        this.timeElapsed = 0.0;
    }

    /*
     * Call PositionMonitor (if any)
     */
    private void tableStateChanged() {
        for(int i=0;i<positionMonitor.size();i++)
            {

            String tags[] = { "x", "y" };
            int values[] = { x, y };
            
             positionMonitor.get(i).positionChanged(tags, values, errorOccurred);

        }
    }
}
