/**
 * File: AlarmingPositionMonitor.java
 * Author: Aman Khatri, (kaman@uab.edu)
 * Assignment: Project 3 EE333 Fall 2010
 * Ver:  1.0.2 09/15/2011 furnishing the program
 * Vers: 1.0.1 09/14/2011 fix order of items
 * Vers: 1.0.0 09/12/2011 initial coding
 * Credits:  thanks to alvin alexander, devdaily.com --
 *           http://www.devdaily.com/java/java-audio-example-java-au-play-sound
 *           Wav sound file from http://www.soundjay.com/phone-sounds-1.html
 */

import java.io.*;
import sun.audio.*;

/**
 * Position monitor that plays error.wav file when error is true
 * @author kaman
 */
public class AlarmingPositionMonitor implements PositionMonitor {

    /**
     * Method called to update position and error state
     * @param tag - array of labels (parallel to value)
     * @param value - array of values (parallel to tag)
     * @param error - true if in error state
     */
    @Override
    public void positionChanged(String[] tag, int[] value, boolean error) {
        
        if ( error ) {

            try {

                // open the sound file as a Java input stream
                String alarmFile = "./Alarm.wav";
                InputStream in = new FileInputStream(alarmFile);

                // create an audiostream from the inputstream
                AudioStream audioStream = new AudioStream(in);

                // play the audio clip with the audioplayer class
                AudioPlayer.player.start(audioStream);
            }
            catch (IOException e) {
                System.out.println("Unexpected error: " + e.getMessage() );
            }
        }
    }
}
