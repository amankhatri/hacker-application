/**
 * File: PrintingPositionMonitor.java
 * Author: Aman Khatri, (kaman@uab.edu)
 * Assignment: Project 3 EE333 Fall 2010
 * Ver:  1.0.2 09/15/2011 furnishing the program
 * Vers: 1.0.1 09/14/2011 fix order of items 
 * Vers: 1.0.0 09/12/2011 initial coding By David Green
 * Credits:  NA
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author kaman
 */
public class IndexTableTest {
    
    public IndexTableTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of isOK method, of class IndexTable.
     */
    @Test
    public void testIsOK() {
        System.out.println("isOK");
        IndexTable instance = new IndexTable(100,100, new PrintingPositionMonitor());
        instance.move(10, 10);
        boolean expResult = true;
        boolean result = instance.isOK();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of isError method, of class IndexTable.
     */
    @Test
    public void testIsError() {
        System.out.println("isError");
        IndexTable instance = new IndexTable(100,100, new PrintingPositionMonitor());
        instance.move(10, 10);
        boolean expResult = false;
        boolean result = instance.isError();
        assertEquals(expResult, result);
      }

    /**
     * Test of isHome method, of class IndexTable.
     */
    @Test
    public void testIsHome() {
        System.out.println("isHome");
        IndexTable instance = new IndexTable(100,100, new PrintingPositionMonitor());
        instance.move(10, 10);
        boolean expResult = true;
        boolean result = instance.isHome();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of getX method, of class IndexTable.
     */
    @Test
    public void testGetX() {
        System.out.println("getX");
        IndexTable instance = new IndexTable(100,100, new PrintingPositionMonitor());
        instance.move(10,10);
        int expResult = 10;
        int result = instance.getX();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of getY method, of class IndexTable.
     */
    @Test
    public void testGetY() {
        System.out.println("getY");
        IndexTable instance = new IndexTable(100,100, new PrintingPositionMonitor());
        instance.move(10, 10);
        int expResult = 10;
        int result = instance.getY();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of toString method, of class IndexTable.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        IndexTable instance = new IndexTable(100,100, new PrintingPositionMonitor());
        instance.move(10, 10);
        String expResult = "";
        String result = instance.toString();
        assertTrue(result!=null);
  
    }

    /**
     * Test of is_complete method, of class IndexTable.
     */
    @Test
    public void testIs_complete() {
        System.out.println("is_complete");
        IndexTable instance = new IndexTable(100,100, new PrintingPositionMonitor());
        instance.move(10, 10);
        boolean expResult = true;
        boolean result = instance.isComplete();
        assertEquals(expResult,result);
    }

    /**
     * Test of time_elapsed method, of class IndexTable.
     */
    @Test
    public void testTime_elapsed() {
        System.out.println("time_elapsed");
        IndexTable instance = new IndexTable(100,100, new PrintingPositionMonitor());
        instance.move(20,15);
        double expResult = 2.0;
        double result = instance.time_elapsed();
        assertTrue(instance.getX()==20&&instance.getY()==15);
       assertTrue(instance.time_elapsed()==2.0);
        
    }

    /**
     * Test of resetError method, of class IndexTable.
     */
    @Test
    public void testResetError() {
        System.out.println("resetError");
        IndexTable instance = new IndexTable(100,100, new PrintingPositionMonitor());
        instance.move(1000, 1000);
        instance.resetError();
        assertTrue(instance.getX()==0&&instance.getY()==0);
    }

    /**
     * Test of reset method, of class IndexTable.
     */
    @Test
    public void testReset() {
        System.out.println("reset");
        IndexTable instance = new IndexTable(100,100, new PrintingPositionMonitor());
        instance.move(10, 10);
        instance.reset();
        assertTrue(instance.getX()==0&&instance.getY()==0);
    }

    /**
     * Test of move method, of class IndexTable.
     */
    @Test
    public void testMove() {
        System.out.println("move");
        IndexTable instance = new IndexTable(100,100, new PrintingPositionMonitor());
        instance.move(10, 10);
        assertTrue(instance.getX()==10&&instance.getY()==10);
    }

    /**
     * Test of moveRelative method, of class IndexTable.
     */
    @Test
    public void testMoveRelative() {
        System.out.println("moveRelative");
        int dx = 5;
        int dy = 5;
        IndexTable instance = new IndexTable(100,100, new PrintingPositionMonitor());
        instance.move(10, 10);
        instance.moveRelative(15, 15);
        assertTrue(instance.getX()==25&&instance.getY()==25);
    }

    /**
     * Test of moveVector method, of class IndexTable.
     */
    @Test
    public void testMoveVector() {
        System.out.println("moveVector");
        int r = 5;
        int theta = 90;
        IndexTable instance = new IndexTable(100,100, new PrintingPositionMonitor());
        instance.move(10, 10);
        instance.moveVector(r, theta);
        assertTrue(instance.getX()==10&&instance.getY()==15);
       
    }
}
