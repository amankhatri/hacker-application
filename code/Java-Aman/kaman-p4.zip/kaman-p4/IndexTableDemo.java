/**
 * File: IndexTableDemo.java
 * Author: Aman Khatri, (kaman@uab.edu)
 * Assignment: Project 4 EE333 Fall 2010
 * Ver:  1.0.2 09/22/2011 furnishing the program
 * Vers: 1.0.1 09/20/2011 fix order of items
 * Vers: 1.0.0 09/21/2011 initial coding
 * Credits:  (Not Applicable)
 */
// This is the test file for index table
// Declaration of testIndex calss
public class IndexTableDemo{
  public static void main(String[] args)
    {
        System.out.println("Aman Khatri, kaman ");
        
        // Incorrect movement of table
        IndexTable obj1 = new IndexTable(100, 100,new StandardOutput());
        obj1.move(200, 200);
        
        //Delay
       // try
       // {
         //   Thread.sleep(3700L);
        //}
        //catch (Exception e) 
        //{
        //}
        
        // Correct movement of table
        System.out.println("correct table");
        IndexTable obj2 = new IndexTable(5, 5, new StandardOutput());
        obj2.move(1, 1);
    }
}
