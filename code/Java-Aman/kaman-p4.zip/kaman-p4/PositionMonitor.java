/**
 * File: PositionMoniter.java
 * Author: Aman Khatri, (kaman@uab.edu)
 * Assignment: Project 4 EE333 Fall 2010
 * Ver:  1.0.2 09/22/2011 furnishing the program
 * Vers: 1.0.1 09/20/2011 fix order of items
 * Vers: 1.0.0 09/21/2011 initial coding
 * Credits:  (Not Applicable)
 */

/**
 *
 * @author kaman
 */
public interface PositionMonitor {
    public void positionChanged(String[] tag, int[] value, boolean error);
    
    
}
