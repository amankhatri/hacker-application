/**
 * File: IndexTable.java
 * Author: Aman Khatri, (kaman@uab.edu)
 * Assignment: Project 4 EE333 Fall 2010
 * Ver:  1.0.2 09/22/2011 furnishing the program
 * Vers: 1.0.1 09/20/2011 fix order of items
 * Vers: 1.0.0 09/21/2011 initial coding
 * Credits:  (Not Applicable)
 */
// Importing Math package
// Declaring the class IndexTable
import java.lang.Math;
public class IndexTable
  
{  
 // Declearing variables
  private static int count= 1;
  private int serialNo=0;
  private int xMax;
  private int yMax;
  private int x;
  private int y;
  private double z=0;
  private double t1=0.0;
  private double t2=0.0;
  private double t3=0.0;
  private double timeElapsed;
  private String[] tag = new String[10];
  private int[] value = new int[10];
  private boolean error;
  Error err = new Error();
  private StandardOutput instance;
 // Declaring Boolean Variables
  private boolean isOk;
  private boolean isError;
  private boolean is_Complete;
  
 /** Constructor: It defines actions of object
   * In this construct the maximum values of the x and y coordinates are input, 
   * serial number applied within, the default position of IndexTable is 0,0
   * and is in non-error state
   */
  public IndexTable(int xNew, int yNew, StandardOutput obj)
  {
    xMax=xNew;
    yMax=yNew;
    x=0;
    y=0;
    serialNo=count;
    count++;
    instance = obj;
  }
  /**Queries: Asks for requirements to be full-filled in order to complete program
   * returns true if not in error state, false otherwise
   */
  public boolean is_complete()
  {
    return true;
  
  }
  public boolean isOk()
  {
    if ( (x>=0&&x<=xMax)&&(y>=0&&y<yMax))
    {
      return true;
    }
    else 
    {
      return false; 
    }
  }
  /**Queries: requests data maintained by the object
   * logical compliment of isOk()
   */
  public boolean isError()
  {
    if(!isOk())
      return true;
    else 
      return false;
  }
  /**Queries: requests data maintained by the object
   * returns true if table is known to be at 0,0 else returns false 
   */
  public boolean isHome()
  {
    if (x==0&&y==0)
      return true;
    else 
      return false;
  }
  /**Queries: requests data maintained by the object
   * returns the present x coordinate of table
   */
  public int getX()
  {
    return x;
  }
  /**Queries: requests data maintained by the object
   * returns the present y coordinate of table
   */
  public int getY()
  {
    return y;
  }
  /**Queries: requests data maintained by the object
   * returns serial number, status , x position and y position of table
   */
  public String toString()
  {
    return ("Table Status:"+serialNo+", Status:"+isOk()+", X:"+getX()+ ",Y:"+y+", Time Elapsed:" +time_elapsed());
  }
  /**Command: Used to change the state of objects
   *  clear error condition without moving table
   */
  public void resetError()
  {
    isOk=true;
    error=false;
  }
  
  /**Command: Used to change the state of objects
   * clear error, move the table to home  position
   */
  public void reset()
  {
      error = false;
      z=0;
    x=0;y=0;
  }
  /**Command: Used to change the state of objects
   * move index table to the required x and y positions and if these
   * position are out of coordinate systems, it goes to the previous 
   * x and y values
   */
  public void move(int x2, int y2)
  {
    //err.positionChanged(null,null,true);
    if ((x>=0 && x<=xMax)&&(y>=0 && y<=yMax))
    {
      x=x2;
      y=y2;
        z=(Math.sqrt((x*x)+(y*y)));
      if((z)<=20)
      {
        t1 += ((z)/5);
        
      }
      else
      {
        t1 += ((z)/50);
      }
    }
    else
    {
        error=true;
        //err.positionChanged(null,null,error);
      t1+=0;
    }
    timeElapsed = t1+t2+t3;
    info();
  }
  
  /**Command: Used to change the state of objects
   * moves the index table to new position by specified incremental amount
   * if these position are out of coordinate systems, it goes to the previous 
   * x and y values
   */
  public void moveRelative(int dx,int dy){
    x= x+dx;
    y=y+dy;
    z=(Math.sqrt((dx*dx)+(dy*dy)));
    if(isOk()){
        if ((z<=20)&&(z>=0)){
        t2+=(z)/5.0;
        }
    else if ((z)>20)
    {
        t2+=(z)/50.0;
     }
    }
         
     if(!isOk())
    {
      x=x-dx;
      y=y-dy;
      t2+=0;
      error=true;
        err.positionChanged(null,null,error);
     }
    timeElapsed = t1+t2+t3;
    info();
  }
    
  /**Command: Used to change the state of objects
   * move the table from present location to new location
   * in the direction of vector. Theta ==o means move along the x axis and 
   * theta==90 means along the y axis. The final position should be rounded to 
   * nearest index position if these position are out of coordinate systems, 
   * it goes to the previous x and y values
   */
  public void moveVector(int r, int theta)
  {
    
    x= x+(int)Math.round(r*Math.cos(Math.toRadians(theta)));
    y=y+(int)Math.round(r*Math.sin(Math.toRadians(theta)));
    z=(Math.sqrt((x*x)+(y*y)));
    if(!isOk())
    {
      x= x-(int)Math.round(r*Math.cos(Math.toRadians(theta)));
      y= y-(int)Math.round(r*Math.sin(Math.toRadians(theta)));
      t3+=0;
      z=0;
      error=true;
      err.positionChanged(null,null,error);
    }
    if((z<=20)&&(z>=0))
    {
       t3+= (z)/5;
       
    }
    else if ((z)>20)
    {
        
        t3+= z/50;
        
    }
    timeElapsed = t1+t2+t3;
    info();
  }
/**Command: Used to change the state of objects
   *calculates the time elapsed in execution of each command
   */
  public double time_elapsed()
          
  {    
      return (timeElapsed);   
  }     
  public void info()
  {
      tag[0] = "x co-ordinate";
      tag[1] = "y co-ordinate";
      value[0] = x;
      value[1] = y;
      instance.positionChanged(tag,value,error);
      err.positionChanged(tag, value, true);
  }

}