/**
 * File: StandardOutput.java
 * Author: Aman Khatri, (kaman@uab.edu)
 * Assignment: Project 4 EE333 Fall 2010
 * Ver:  1.0.2 09/22/2011 furnishing the program
 * Vers: 1.0.1 09/20/2011 fix order of items
 * Vers: 1.0.0 09/21/2011 initial coding
 * Credits:  (Not Applicable)
 */

/**
 *
 * @author kaman
 */
public class StandardOutput implements PositionMonitor {
    public StandardOutput ()
    {
    }
    
    @Override
    public void positionChanged(String[] tag, int[] value, boolean error)
    {
        String status;
        if (error == true)
        {
            status = "Error State";
        }
        else{
            status = "working";
        }
        
        System.out.println("Device is " + status + ".");
        System.out.println(tag[0] + " is in position " + value[0] + ".");
        System.out.println(tag[1] + " is in position " + value[1] + ".");
    }
}

