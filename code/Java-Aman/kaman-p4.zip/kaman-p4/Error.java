/*
 * File: Error.java
 * Author: Aman Khatri, (kaman@uab.edu)
 * Assignment: Project 4 EE333 Fall 2010
 * Ver:  1.0.2 09/18/2011 furnishing the program
 * Vers: 1.0.1 09/19/2011 fix order of items
 * Vers: 1.0.0 09/20/2011 initial coding
 * Credits:  dream.in.code<http://www.dreamincode.net/forums/topic/14083-incredibly-easy-way-to-play-sounds/>
 */

import java.io.*;
import sun.audio.*;

public class Error implements PositionMonitor  {
 
   // public Error(){}

    @Override
    public void positionChanged(String[] tag, int[] value, boolean error){
        if (error == true) {
            // open the sound file as a Java input stream
            String errorFile = (".\\error.au");
            try {
                InputStream in = new FileInputStream(errorFile);
                // create an audiostream from the inputstream
                AudioStream aStream = new AudioStream(in);
                // play the audio clip with the audioplayer class
                AudioPlayer.player.start(aStream);
            } catch (Exception s) {
           }

        }
    }
}



