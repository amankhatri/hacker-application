/**
 * File: IndexTable.java
 * Author: Aman Khatri, (kaman@uab.edu)
 * Assignment: Project 3 EE333 Fall 2010
 * Ver:  1.0.2 09/15/2011 furnishing the program
 * Vers: 1.0.1 09/14/2011 fix order of items
 * Vers: 1.0.0 09/12/2011 initial coding
 * Credits:  (Not Applicable)
 */

//importing Scanner Method
import java.util.Scanner;
// IndexTableDemo class
public class IndexTableDemo{
  //declaration of static variables
  private static Scanner input = new Scanner(System.in);
  private static IndexTable[] indexTable = new IndexTable[11];
  //Main Function
  public static void main(String[] argv){
    if(argv.length>0)
    {
      if(argv[0].equals("-h"))
      {
        help();
      }
    }
    {
      
      int size = 1;
      String str;
      System.out.println("IndexTableDemo 1.0 by Aman Khatri");
      
      //Loop structure to create objects
      while(true){
        //prints Commands
        System.out.println("Command :");
        str= input.nextLine();
        String userIn[] = str.split(" ");
        // creating table
        if ((userIn.length==3) && (userIn[0].equals("createtable")) && (size<=10)){
          try{
            indexTable[size] = new IndexTable(Integer.parseInt(userIn[1]),Integer.parseInt(userIn[2]));
            System.out.println(indexTable[size].toString());
            size++;
          }catch(Exception e){
            
          }
        }
        else if ((userIn.length==4) && (userIn[0].equals("move")))
          try{
          indexTable[Integer.parseInt(userIn[1])].move(Integer.parseInt(userIn[2]),Integer.parseInt(userIn[3]));
        }catch(Exception e){}
        else if ((userIn.length==4) && (userIn[0].equals("moverelative"))){
          indexTable[Integer.parseInt(userIn[1])].moveRelative(Integer.parseInt(userIn[2]), Integer.parseInt(userIn[3]));
        }
        else if((userIn.length==4) && (userIn[0].equals("movevector"))){
          indexTable[Integer.parseInt(userIn[1])].moveVector(Integer.parseInt(userIn[2]),Integer.parseInt(userIn[3]));
        }
        else if(userIn[0].equals("reset")&&(((Integer.parseInt(userIn[1])<=size))))
        {
          try{
            indexTable[Integer.parseInt(userIn[1])].reset();
          }catch(Exception e){
          }
        }
        else if(userIn[0].equals("time_elapsed")&&(((Integer.parseInt(userIn[1])<=size)))){
          try{
            System.out.println(indexTable[Integer.parseInt(userIn[1])].time_elapsed());
          }catch(Exception e) {
          }
        }
        else if(userIn[0].equals("is_complete?"))
          try{
          System.out.println("true");
        }catch(Exception e){}
        else if(userIn[0].equals("-h"))
          try {
          help();
        } catch(Exception e){}
        else if (userIn[0].equals("tablestatus")&&((Integer.parseInt(userIn[1]))<=size))
          try {
          System.out.println(indexTable[Integer.parseInt(userIn[1])].toString());
        }catch(Exception e){}
        else if (userIn[0].equals("quit"))
        {
          break;
        }
        else{
          System.out.println("See help");
        }
        
      }
    }}
  //Methods for help and printing command.
  public static void help()
  {
    System.out.println(" IndexTableDemo 1.0 Aman Khatri");
    System.out.println(" This Program is supplied for p3 of EE333 Fall 2011");
    System.out.println(" Commands: ");
    System.out.println(" createtable {max_x} {max_y}");
    System.out.println(" move {Table Serial Number} {x} {y}");
    System.out.println(" moverelative {Table Serial Number} {dx} {dy}");
    System.out.println(" movevector {Table Serial Number}");
    System.out.println(" reset {Table Serial Number");
    System.out.println(" time_elapsed {Table Serial Number}");
    System.out.println(" quit ");
    System.out.println(" Lines that start with any other words are ignored.");
    System.out.println(" Lines that are missing retuired data are ignored.");
    System.out.println(" Ten IndexTables can be created.");
    System.out.println(" Commands to IndexTables that don't exist are ignored.");
    System.out.println(" Commands with improper arguments are ignored.");
    System.out.println(" Table serial number should also correspond to the creation order.");
    System.out.println(" Built with Netbeans.");
  }
  
}