/**
 * File: IndexTable.java
 * Author: Aman Khatri, (kaman@uab.edu)
 * Assignment: Project 3 EE333 Fall 2010
 * Ver:  1.0.2 09/15/2011 furnishing the program
 * Vers: 1.0.1 09/14/2011 fix order of items
 * Vers: 1.0.0 09/12/2011 initial coding
 * Credits:  (Not Applicable)
 */

import org.junit.After;
import org.junit.Before;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author kaman
 */
public class IndexTableTest {
    
    public IndexTableTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of is_complete method, of class IndexTable.
     */
    @Test
    public void testIs_complete() {
        System.out.println("is_complete");
        IndexTable instance = new IndexTable(200,200);
        boolean expResult = true;
        boolean result = instance.is_complete();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of isOk method, of class IndexTable.
     */
    @Test
    public void testIsOk() {
        System.out.println("isOk");
        IndexTable instance = new IndexTable(200,200);
        boolean expResult = true;
        boolean result = instance.isOk();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of isError method, of class IndexTable.
     */
    @Test
    public void testIsError() {
        System.out.println("isError");
        IndexTable instance = new IndexTable(200,200);
        boolean expResult = false;
        boolean result = instance.isError();
        assertEquals(expResult, result);
      }

    /**
     * Test of isHome method, of class IndexTable.
     */
    @Test
    public void testIsHome() {
        System.out.println("isHome");
        IndexTable instance = new IndexTable(200,200);
        boolean expResult = true;
        boolean result = instance.isHome();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of getX method, of class IndexTable.
     */
    @Test
    public void testGetX() {
        System.out.println("getX");
        IndexTable instance = new IndexTable(200,200);
        instance.move(50,0);
        int expResult= 50;
        int result = instance.getX();
        assertEquals(50, result);
     
    }

    /**
     * Test of getY method, of class IndexTable.
     */
    @Test
    public void testGetY() {
        System.out.println("getY");
        IndexTable instance = new IndexTable(200,200);
        instance.move(0,90);
        int expResult =90;
        int result = instance.getY();
        assertEquals(expResult, result);
     }

    /**
     * Test of toString method, of class IndexTable.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        IndexTable instance = new IndexTable(200,200);
        String expResult = "";
        String result = instance.toString();
        assertTrue(!expResult.equals(result)&& result!=null);
      
    }

    /**
     * Test of resetError method, of class IndexTable.
     */
    @Test
    public void testResetError() {
        System.out.println("resetError");
        IndexTable instance = new IndexTable(200,200);
        instance.resetError();
        assertFalse(instance.isOk()==false);
         }

    /**
     * Test of reset method, of class IndexTable.
     */
    @Test
    public void testReset() {
        System.out.println("reset");
        IndexTable instance = new IndexTable(200,200);
        instance.move(10,05);
        instance.reset();
        assertTrue(instance.getX()==0&&instance.getY()==0);
    
    }

    /**
     * Test of move method, of class IndexTable.
     */
    @Test
    public void testMove() {
        System.out.println("move");
        int x2 = 20;
        int y2 = 30;
        IndexTable instance = new IndexTable(200,200);
        instance.move(x2, y2);
        assertTrue(instance.getX()==20&&instance.getY()==30);
      }

    /**
     * Test of moveRelative method, of class IndexTable.
     */
    @Test
    public void testMoveRelative() {
        System.out.println("moveRelative");
        int dx = 10;
        int dy = 15;
        int x=50;
        int y=100;
        IndexTable instance =new IndexTable(200,200);
        instance.move(50, 100);
        instance.moveRelative(dx, dy);
        assertTrue(instance.getX()==60&&instance.getY()==115);
        
    }

    /**
     * Test of moveVector method, of class IndexTable.
     */
    @Test
    public void testMoveVector() {
        System.out.println("moveVector");
        int r = 0;
        int theta = 0;
        IndexTable instance = new IndexTable(200,200);
        instance.moveVector(r, theta);
        assertTrue(instance.getX()==0&&instance.getY()==0);
        
    }

    /**
     * Test of time_elapsed method, of class IndexTable.
     */
    @Test
    public void testTime_elapsed() {
        System.out.println("time_elapsed");
        IndexTable instance = new IndexTable(200,200);
        instance.move(10,10);
        double expResult = 4.0;
        double result = instance.time_elapsed();
        assertTrue(instance.time_elapsed()==4);
        
    }
}
