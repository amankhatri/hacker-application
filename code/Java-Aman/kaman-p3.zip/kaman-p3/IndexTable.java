/**
 * File: IndexTable.java
 * Author: Aman Khatri, (kaman@uab.edu)
 * Assignment: Project 3 EE333 Fall 2010
 * Ver:  1.0.2 09/15/2011 furnishing the program
 * Vers: 1.0.1 09/14/2011 fix order of items
 * Vers: 1.0.0 09/12/2011 initial coding
 * Credits:  (Not Applicable)
 */
// Importing Math package
// Declaring the class IndexTable
import java.lang.Math;
public class IndexTable
  
{  
 // Declearing variables
  private static int count= 1;
  private int serialNo=0;
  private int xMax;
  private int yMax;
  private int x;
  private int y;
  private int x3;
  private int y3;
  private int dx;
  private int dy;
  private int z=0;
  private double t1=0.0;
  private double t2=0.0;
  private double t3=0.0;
  private double timeElapsed;
 // Declaring Boolean Variables
  private boolean isOk;
  private boolean isError;
  private boolean is_Complete;
  
 /** Constructor: It defines actions of object
   * In this construct the maximum values of the x and y coordinates are input, 
   * serial number applied within, the default position of IndexTable is 0,0
   * and is in non-error state
   */
  public IndexTable(int xNew, int yNew)
  {
    xMax=xNew;
    yMax=yNew;
    x=0;
    y=0;
    serialNo=count;
    count++;
  }
  /**Queries: Asks for requirements to be full-filled in order to complete program
   * returns true if not in error state, false otherwise
   */
  public boolean is_complete()
  {
    return true;
  
  }
  public boolean isOk()
  {
    if ( (x>=0&&x<=xMax)&&(y>=0&&y<yMax))
    {
      return true;
    }
    else 
    {
      return false; 
    }
  }
  /**Queries: requests data maintained by the object
   * logical compliment of isOk()
   */
  public boolean isError()
  {
    if(!isOk())
      return true;
    else 
      return false;
  }
  /**Queries: requests data maintained by the object
   * returns true if table is known to be at 0,0 else returns false 
   */
  public boolean isHome()
  {
    if (x==0&&y==0)
      return true;
    else 
      return false;
  }
  /**Queries: requests data maintained by the object
   * returns the present x coordinate of table
   */
  public int getX()
  {
    return x;
  }
  /**Queries: requests data maintained by the object
   * returns the present y coordinate of table
   */
  public int getY()
  {
    return y;
  }
  /**Queries: requests data maintained by the object
   * returns serial number, status , x position and y position of table
   */
  public String toString()
  {
    return ("Table Status:"+serialNo+", Status:"+isOk()+", X:"+getX()+ ",Y:"+y+", Time Elapsed:" +time_elapsed());
  }
  /**Command: Used to change the state of objects
   *  clear error condition without moving table
   */
  public void resetError()
  {
    isOk=true;
  }
  
  /**Command: Used to change the state of objects
   * clear error, move the table to home  position
   */
  public void reset()
  {
    x=0;y=0;
  }
  /**Command: Used to change the state of objects
   * move index table to the required x and y positions and if these
   * position are out of coordinate systems, it goes to the previous 
   * x and y values
   */
  public void move(int x2, int y2)
  {
    
    if ((x>=0 && x<=xMax)&&(y>=0 && y<=yMax))
    {
      x=x2;
      y=y2;
    
      if((x+y)<=20)
      {
        t1 += ((x+y)/5);
        
      }
      else
      {
        t1 += ((x+y)/50);
      }
    }
    else
    {
      t1+=0;
    }
    timeElapsed = t1+t2+t3;
  }
  
  /**Command: Used to change the state of objects
   * moves the index table to new position by specified incremental amount
   * if these position are out of coordinate systems, it goes to the previous 
   * x and y values
   */
  public void moveRelative(int dx,int dy){
    x= x+dx;
    y=y+dy;
    if(isOk()){
        if ((dx+dy)<=20){
        t2+=(dx+dy)/5.0;
        }
    else if ((dx+dy)>20)
    {
        t2+=(dx+dy)/50.0;
     }
    }
         
     if(!isOk())
    {
      x=x-dx;
      y=y-dy;
      t2+=0;
     }
    timeElapsed = t1+t2+t3;
  }
    
  /**Command: Used to change the state of objects
   * move the table from present location to new location
   * in the direction of vector. Theta ==o means move along the x axis and 
   * theta==90 means along the y axis. The final position should be rounded to 
   * nearest index position if these position are out of coordinate systems, 
   * it goes to the previous x and y values
   */
  public void moveVector(int r, int theta)
  {
    
    x= x+(int)Math.round(r*Math.cos(Math.toRadians(theta)));
    y=y+(int)Math.round(r*Math.sin(Math.toRadians(theta)));
    if(!isOk())
    {
      x= x-(int)Math.round(r*Math.cos(Math.toRadians(theta)));
      y= y-(int)Math.round(r*Math.sin(Math.toRadians(theta)));
      t3+=0;
    }
    if((x+y)<=20)
    {
       t3+= ((int)Math.round(r*Math.cos(Math.toRadians(theta)))+(int)Math.round(r*Math.sin(Math.toRadians(theta))))/5;
       
    }
    else if ((x+y)>20)
    {
        t3+= ((int)Math.round(r*Math.cos(Math.toRadians(theta)))+(int)Math.round(r*Math.sin(Math.toRadians(theta))))/50;
        
    }
    timeElapsed = t1+t2+t3;
    
  }
/**Command: Used to change the state of objects
   *calculates the time elapsed in execution of each command
   */
  public double time_elapsed()
          
  {    
      return (timeElapsed);   
  }     
  

}
