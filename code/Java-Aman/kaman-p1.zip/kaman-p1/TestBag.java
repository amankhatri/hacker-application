/*
 * File: TestBag.java
 * Author: Aman Khatri, (kaman@uab.edu)
 * Assignment: Project 1 EE333 Fall 2010
 * Ver:  1.0.3 08/29/2011 furnishing the program
 * Vers: 1.0.2 08/28/2011 to fix arrays
 * Vers: 1.0.1 08/28/2011 fix order of items
 * Vers: 1.0.0 07/27/2011 initial coding
 * Credits:  (Not Applicable)
 */
/** This file is to test 'Capacitor.Java'
  */
// Declaring the class TestBag
public class TestBag
{
  //Invoking the main class
  public static void main(String[] args)
  {
    // Creating a new variable of type CapacitorBag
     CapacitorBag cb1 = new CapacitorBag();
     // Running the query for the method 'pickC'
     cb1.pickC();
     // Running the query for the method 'getCount'
     System.out.println("0.01uf Capacitor appears for " + (cb1.getCount(0)));
     System.out.println("0.047uf Capacitor appears for " + (cb1.getCount(1)+cb1.getCount(2)));
     System.out.println("0.1uf Capacitor appears for " + (cb1.getCount(3)));
     System.out.println("0.47uf Capacitor appears for " + (cb1.getCount(4)));
     // Running the query for the method 'getAverageSuplied'
     System.out.println(cb1.getAverageSupplied());
     // Running the command for the method 'reset()'
     cb1.reset();
  }
}
