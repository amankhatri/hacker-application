/*
 * File: CapacitorBag.java
 * Author: Aman Khatri, (kaman@uab.edu)
 * Assignment: Project 1 EE333 Fall 2011
 * Ver:  1.0.3 08/29/2011 furnishing the program
 * Vers: 1.0.2 08/28/2011 to fix arrays
 * Vers: 1.0.1 08/28/2011 fix order of items
 * Vers: 1.0.0 07/27/2011 initial coding
 * Credits:  (Not Applicable)
 */


// Importing class 'Random' from library
import java.util.Random;
// Creating a Class 
public class CapacitorBag
{
  private double myArray[] = {0.01E-6,0.047E-6,.047E-6,0.1E-6,0.47E-6}; // Declaring variable 
  private int array[] = {0,0,0,0,0}; // Creating an empty array 
  Random rand = new Random();       // creading a variable of type Random
 
  //This is a Constructor for the class 'CapacitorBag'
  public CapacitorBag()
  {
  }
  /** Query
   * This method picks up a random value from the set of capacitance value in the array name 'myArray'
   */ 
  public double pickC()
  {
    int m = rand.nextInt(myArray.length);
    array[m]++;
    return myArray[m];
  }
  /**Query
   * This method counts the number of times each capacitor appears in  randomly choosen capacitors
   */ 
  public int getCount(int selector)
  {
    if(selector == 1 || selector == 2)
      return array[1]+array[2];
    else
      return array[selector];
  }
  /**Query
    * This method computes the average of all the randomly selected capacitors 
    */
  public double getAverageSupplied()
  {
    double sum = 0.0;
    int count= 0;
    for (int arrl=0;arrl<5;arrl++)
    {
      sum = sum + myArray[arrl]*array[arrl];
      count += array[arrl];
    }
    return sum/count;
  }
  /**Command
   * This method resets the counter to zero
   */
  public void reset()
  {
    for (int i = 0; i < array.length; i++)
      array[i] = 0;
  }
}
