/*
 * File: runTest.java
 * Author: Aman Khatri, (kaman@uab.edu)
 * Assignment: Project 2 EE333 Fall 2010
 * Ver:  1.0.2 09/07/2011 furnishing the program
 * Vers: 1.0.1 09/05/2011 fix order of items
 * Vers: 1.0.0 09/04/2011 initial coding
 * Credits:  (Not Applicable)
 */
// This is the test file for index table
// Declaration of testIndex calss
public class runTest{
  public static void main(String args[])
  {
   // Declaring the first object with,input being the maximum values of x and y
    IndexTable index = new IndexTable(30,20);
    index.isOk();
    index.isError();
    index.isHome();
    index.move(100,2);
    index.resetError();
    System.out.println(index.toString());
    index.isError();
    System.out.println(index.toString());
    index.moveRelative(30, 1);
    System.out.println(index.toString());
    index.moveVector(1000,30);
    System.out.println(index.toString());
    index.reset();

    // Declaring the second object with, input being the maximum values of x and y
    IndexTable a = new IndexTable(60,30);
    a.isOk();
    a.isError();
    a.isHome();
    a.move(1,2);
    System.out.println(a.toString());
    a.moveRelative(10, 5);
    System.out.println(a.toString());
    a.moveVector(10,900);
    System.out.println(a.toString());
    a.reset();
  }
}